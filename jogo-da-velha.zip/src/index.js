import React from 'react';
import ReactDOM from 'react-dom/client';
import Jogodavelha from './Jogodavelha';


const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(
  <React.StrictMode>
    <Jogodavelha />
  </React.StrictMode>
);

